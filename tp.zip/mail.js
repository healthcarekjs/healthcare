var mailer = require('nodemailer');



var transporter  = mailer.createTransport({
    service:'gmail',
    auth:{
        user: 'healthcaresystem2020@gmail.com',
        pass : 'healthcare@2020'
    }
});

module.exports = transporter;